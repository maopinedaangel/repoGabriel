
var x = 5;
console.log(x);
var y;
y = parseInt(prompt("Insertar un número"));
console.log(y);


if (y > 5) {
  console.log(y);
} else {
  y++;
  console.log(y);
}


for (i = 0; i < 5; i++) {
   console.log(i); 
}

k = 0;
while ( k < 5) {
   console.log("Valores de k: " + k);
   k++; 
}

var array1 = [];
var array2 = new Array();
var array3 = [3, 5, 6];

array1.push(8);
console.log(array1[0]);
console.log(array3[0]);
console.log(array3);


var sumar = function(num1, num2) {
  var suma = num1 + num2;
  return suma;
}

//var z = x + y;
var z = sumar(x, y);
console.log(z);

var w = sumar(x, z);
console.log(w);